from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import LoanAccount,Client,User,Payments,Receipts

# Register your models here.
admin.site.register(LoanAccount)
admin.site.register(Client)
admin.site.register(User)
admin.site.register(Payments)
admin.site.register(Receipts)
